#ifndef _GLOBALS_H 
#define _GLOBALS_H

//--------------------------------------------------------------------
// Include Files
#include "lrun.h"
#include "web_api.h"
#include "lrw_custom_body.h"


int count[3];
char *login1, *login2, *login3, *pass1, *pass2, *pass3;

//--------------------------------------------------------------------
// Global Variables


#endif // _GLOBALS_H
